#include "header.h"
int main(){

	int entrada;
	char* input_string = (char*)malloc(20*sizeof(char));
	scanf("%d", &entrada);
	scanf("%s", input_string);
	//entrada = 8;
	//input_string = "binario1.bin";

	FILE* bin_entrada = fopen(input_string, "rb");
	free(input_string);

	switch (entrada) {
		case 8:
			funcionalidade8(bin_entrada, 1);
			break;
		case 9:
			funcionalidade9(bin_entrada);
			break;
		case 10:
			funcionalidade10(bin_entrada);
			break;
		case 11:
			funcionalidade11(bin_entrada);
			break;
		case 12:
			funcionalidade12(bin_entrada);
			break;
		default:
			break;
	}
	//fclose(bin_entrada);

	//printf("\nfim da execução (teste).");

	return 0;

}