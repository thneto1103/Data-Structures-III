#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TAM_MAX_VET 500

// ESTRUTURAS

typedef struct Node {
    char data[50];  // Assumindo que a string terá no máximo 49 caracteres
    struct Node* next;
} Node;

// Definição da estrutura da fila
typedef struct Queue {
    Node* front;  // Frente da fila
    Node* rear;   // Final da fila
} Queue;

typedef struct Vertice{
	char* nomeTecnologia;
	int grupo;
	int grauEntrada;
	int grauSaida;
	int grau;
    int peso[30];
	Queue lista;
} Vertice;

typedef struct Registro{
    char removido;
    int grupo;
    int popularidade;
    int peso;
    int tamanhoTecnologiaOrigem;
    char* nomeTecnologiaOrigem;
    int tamanhoTecnologiaDestino;
    char* nomeTecnologiaDestino;
} Registro; // tamanho 1 + 5 * 4 + 2*tam_variavel = aprox. 30

// FIM DAS ESTRUTURAS

// PROTOTIPOS

void funcionalidade8(FILE* arq, int print);
void funcionalidade9(FILE* arq);
void funcionalidade10(FILE* arq);
void funcionalidade11(FILE* arq);
void funcionalidade12(FILE* arq);

// FIM DOS PROTOTIPOS


// >>>>>>>>>>>>>>>>> FUNCOES DE TAD DE FILA <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

// Função para inicializar a fila
void initializeQueue(Queue* queue) {
    queue->front = queue->rear = NULL;
}

// Função para verificar se a fila está vazia
int isEmpty(Queue* queue) {
    return queue->front == NULL;
}

// Função para enfileirar uma string na fila
void enqueue(Queue* queue, char* data) {

    if (data == "0"){
        return;
    }
    // Cria um novo nó
    Node* newNode = (Node*)malloc(sizeof(Node));
    if (newNode == NULL) {
        fprintf(stderr, "Erro ao alocar memória.\n");
        exit(EXIT_FAILURE);
    }

    // Configura os dados do nó
    strncpy(newNode->data, data, sizeof(newNode->data) - 1);

    //for (int i = 0; i < 3; i++){
      //  newNode->data[0] = data[0];
    //}

    newNode->data[sizeof(newNode->data) - 1] = '\0';  // Garante que a string seja terminada corretamente
    newNode->next = NULL;

    // Se a fila estiver vazia, o novo nó será tanto a frente quanto o final da fila
    if (isEmpty(queue)) {
        queue->front = queue->rear = newNode;
    } else {
        // Adiciona o novo nó ao final da fila e atualiza o final
        queue->rear->next = newNode;
        queue->rear = newNode;
    }
    //free(newNode->data);
}

// Função para desenfileirar uma string da fila
char* dequeue(Queue* queue) {
    if (isEmpty(queue)) {
        //fprintf(stderr, "A fila está vazia.\n");
        return "VAZIA";
        //exit(EXIT_FAILURE);
    }

    // Obtém a string da frente da fila
    char* frontValue = strdup(queue->front->data);

    // Mantém uma referência temporária ao nó a ser removido
    Node* temp = queue->front;

    // Atualiza a frente da fila para o próximo nó
    queue->front = queue->front->next;

    // Libera a memória do nó removido
    free(temp);

    // Retorna a string removida
    return frontValue;
}

// Função para imprimir a fila
void printQueue(Queue* queue, int* vet, char* nomeTec, int grupo, int grauSaida, int grauEntrada) {
    if (isEmpty(queue)) {
        printf("A fila está vazia.\n");
        return;
    }

    // Percorre a fila e imprime as strings
    Node* current = queue->front;
    //printf("Fila: ");
    int i = 0;
    while (current != NULL) {
        printf("%s ", nomeTec);
        printf("%d ", grupo);
        printf("%d ", grauEntrada);
        printf("%d ", grauSaida);
        printf("%d ", grauEntrada+grauSaida);
        printf("%s ", current->data);
        printf("%d\n", vet[i]);
        i++;
        current = current->next;
    }
}

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//>>>>>>>>>>>>>>> FIM DAS FUNCOES DE TAD DE FILA <<<<<<<<<<<<<<<<<<<<<<<<


// %%%%%%%%%%%%%%%%%%% FUNCOES AUXILIARES %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

int leitura_binario(Registro *registros, FILE *arq){

    int i = 0;
    char byte;

    fseek(arq, 13, SEEK_SET);

    //while (fread(&registros[i].removido, sizeof(char), 1, arq) == 1) {
    while (fread(&registros[i].removido, sizeof(char), 1, arq) != 0) { 
    	
        fread(&registros[i].grupo, sizeof(int), 1, arq);
        fread(&registros[i].popularidade, sizeof(int), 1, arq);
        fread(&registros[i].peso, sizeof(int), 1, arq);
        fread(&registros[i].tamanhoTecnologiaOrigem, sizeof(int), 1, arq);

        registros[i].nomeTecnologiaOrigem = (char*) malloc(registros[i].tamanhoTecnologiaOrigem*sizeof(char)+1);
        fread(registros[i].nomeTecnologiaOrigem, sizeof(char), registros[i].tamanhoTecnologiaOrigem, arq);


        fread(&registros[i].tamanhoTecnologiaDestino, sizeof(int), 1, arq);

        registros[i].nomeTecnologiaDestino = (char*) malloc(registros[i].tamanhoTecnologiaDestino*sizeof(char)+1);
        fread(registros[i].nomeTecnologiaDestino, sizeof(char), registros[i].tamanhoTecnologiaDestino, arq);

        registros[i].nomeTecnologiaOrigem[registros[i].tamanhoTecnologiaOrigem] = '\0';
        registros[i].nomeTecnologiaDestino[registros[i].tamanhoTecnologiaDestino] = '\0';


        fseek(arq, 76 - 21 - registros[i].tamanhoTecnologiaOrigem - registros[i].tamanhoTecnologiaDestino, SEEK_CUR);
        i++;
    }
    return i;
}

char* conteudoEntreAspas(const char* input) { // FUNCAO DO ChatGPT
    
    const char* inicio = strchr(input, '"'); // Encontra a primeira aspa
    if (inicio == NULL) {
        return NULL; // Não há aspas
    }

    inicio++; // Avança para o próximo caractere após a primeira aspa

    const char* fim = strchr(inicio, '"'); // Encontra a segunda aspa
    if (fim == NULL) {
        return NULL; // Não há segunda aspa
    }

    // Calcula o tamanho do conteúdo entre as aspas
    size_t tamanho = fim - inicio;

    // Aloca memória para o conteúdo entre as aspas
    char* resultado = (char*)malloc(tamanho + 1);
    if (resultado == NULL) {
        return NULL; // Falha na alocação de memória
    }

    // Copia o conteúdo entre as aspas para o resultado
    strncpy(resultado, inicio, tamanho);
    resultado[tamanho] = '\0'; // Adiciona um caractere nulo no final

    return resultado;
}

Registro campo_compativel(FILE* arq_indice, Registro registro, char* campo, char* input){

    if (!strcmp(campo, "peso")){
        if (atoi(input) == registro.peso){
            return registro;
        }
    }

    if (!strcmp(campo, "popularidade")){
        if (atoi(input) == registro.popularidade){
            return registro;
        }
    }

    if (!strcmp(campo, "grupo")){
        if (atoi(input) == registro.grupo){
            return registro;
        }
    }

    if (!strcmp(campo, "nomeTecnologiaOrigem")){
        //scan_quote_string(input);
        if (!strcmp(conteudoEntreAspas(input), registro.nomeTecnologiaOrigem)){
            return registro;
        }
    }

    if (!strcmp(campo, "nomeTecnologiaDestino")){
        //scan_quote_string(input);
        if (!strcmp(conteudoEntreAspas(input), registro.nomeTecnologiaDestino)){
            return registro;
        }
    }

    if (!strcmp(campo, "nomeTecnologiaOrigemDestino")){
        // fazer busca no arquivo de indice
        return registro; // não é essa linha
    }
}

int particionar(char **arr, int baixo, int alto) {
    char *pivot = arr[alto]; // Escolha o último elemento como pivô
    int i = (baixo - 1);     // Índice do menor elemento

    for (int j = baixo; j <= alto - 1; j++) {
        // Compara as strings e troca se necessário
        if (strcmp(arr[j], pivot) < 0) {
            i++;
            // Troca arr[i] e arr[j]
            char *temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
    }

    // Troca arr[i+1] e arr[alto] (pivô)
    char *temp = arr[i + 1];
    arr[i + 1] = arr[alto];
    arr[alto] = temp;

    return (i + 1);
}

// Função principal QuickSort
void quickSort(char **arr, int baixo, int alto) {
    if (baixo < alto) {
        // Encontrar o índice de partição
        int indiceParticao = particionar(arr, baixo, alto);

        // Recursivamente ordenar os elementos antes e depois da partição
        quickSort(arr, baixo, indiceParticao - 1);
        quickSort(arr, indiceParticao + 1, alto);
    }
}

int compara_elementos(char* str1, Vertice* array, int tam, int* aux){

    for (int i = 0; i < tam; i++){
        if (!strcmp(str1, array[i].nomeTecnologia)){
            *aux = i;
            return 1;
        }
    }
    return 0;

}

int verif_pos_livre(int* vet, int tam){
    int i = 0;
    while(vet[i] != -1 && i < tam){
        i++;
    }
    return i;
}

// %%%%%%%%%%%%%%%%%%% FIM DAS FUNCOES AUXILIARES %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////




void funcionalidade8(FILE* arq, int print){

    //printf("funcionalidade8!");
    
    Vertice* vertices = (Vertice*) malloc(TAM_MAX_VET*sizeof(Vertice));

    Registro* registros = (Registro*) malloc(TAM_MAX_VET*sizeof(Registro));
    leitura_binario(registros, arq);
    int k = leitura_binario(registros, arq); // k = numero de registros lidos

    // INICIALIZANDO AS LISTAS DE CADA VERTICE
    for(int i = 0; i < k; i++){
        initializeQueue(&(vertices[i].lista));
    }

    // INICIALIZANDO ATRIBUTOS DOS VERTICES
    for(int i = 0; i < k; i++){
        vertices[i].nomeTecnologia = malloc(30*sizeof(char));
        //vertices[i].nomeTecnologia = "NULL";
        strcpy(vertices[i].nomeTecnologia, "NULL\0");
        vertices[i].grauSaida = 0;
        vertices[i].grauEntrada = 0;
    }


    //printf("%s\n", registros[0].nomeTecnologiaOrigem);
    //vertices[0].nomeTecnologia = NULL;
    
    int tam = 1;
    int pos = 0;
    int aux;

    // ATRIBUINDO OS NOMES DE TECNOLOGIA AOS VERTICES
    for (int i = 0; i < k; i++){
        if (!compara_elementos(registros[i].nomeTecnologiaOrigem, vertices, tam, &aux)){
            vertices[pos].nomeTecnologia = registros[i].nomeTecnologiaOrigem;
            pos++;
            tam++;
        }   
    }

    // ATRIBUINDO A UM ARRAY DE STRINGS O NOMES DE TECNOLOGIA DE CADA VERTICE A SEREM ORDENADOS
    char ** array = (char**) malloc((tam)*sizeof(char*));
    for (int i = 0; i < tam - 1; i++){
        array[i] = vertices[i].nomeTecnologia;
    }

    quickSort(array, 0, tam - 2);

    // INSERINDO DE FORMA ORDENADA OS NOMES NO ARRAY DE VERTICES
    for (int i = 0; i < tam - 1; i++){
        vertices[i].nomeTecnologia = array[i];
    }


    // INICIALIZANDO PESOS COM VALOR NULO
    for(int i = 0; i < tam - 1; i++){
        for (int j = 0; j < 30; j++){
            vertices[i].peso[j] = -1;
        }
    }

    // INSERINDO TECNOLOGIAS NAS LISTAS ENCADEADADAS DE CADA VERTICE. (AQUI A MAGIA ACONTECE)
    
    for(int i = 0; i < k; i++){
        if (compara_elementos(registros[i].nomeTecnologiaOrigem, vertices, tam, &aux)){
            enqueue(&(vertices[aux].lista), registros[i].nomeTecnologiaDestino);
            vertices[aux].grauSaida++;
            int w = verif_pos_livre(vertices[aux].peso, 30);
            vertices[aux].peso[w] = registros[i].peso;
            vertices[aux].grupo = registros[i].grupo;
            compara_elementos(registros[i].nomeTecnologiaDestino, vertices, tam, &aux);
            vertices[aux].grauEntrada++;
        }
    }


    //int numero_elementos = 0;
    if (print){
        for (int i = 0; i < tam - 1; i++){
        printQueue(&(vertices[i].lista), vertices[i].peso, vertices[i].nomeTecnologia, vertices[i].grupo, vertices[i].grauSaida, vertices[i].grauEntrada);
        }   
    }
    

    free(registros);

    for(int i = 0; i < k; i++){
        free(vertices[i].nomeTecnologia);
        //free(vertices[i].peso);
    }

    free(array);
    free(vertices);
    fclose(arq);
}


void funcionalidade9(FILE* arq){
    printf("funcionalidade9!");
}
void funcionalidade10(FILE* arq){
    
    int n;
    scanf("%d", &n);

    Registro* registros = (Registro*) malloc(TAM_MAX_VET*sizeof(Registro));
    leitura_binario(registros, arq);
    int k = leitura_binario(registros, arq); // k = numero de registros lidos

    char** inputs_nomeTec = (char**)malloc(n*sizeof(char*));

    for(int i = 0; i < n; i++){
        inputs_nomeTec[i] = (char*)malloc(30 * sizeof(char));
        scanf("%s", inputs_nomeTec[i]);
        inputs_nomeTec[i] = conteudoEntreAspas(inputs_nomeTec[i]);
    }

    char** aux_array = (char**) malloc(20*sizeof(char*));
    int aux_tam = 0;
    for(int i = 0; i < n; i++){
        printf("%s: ", inputs_nomeTec[i]);
        for (int j = 0; j < k; j++){
            if (!strcmp(inputs_nomeTec[i], registros[j].nomeTecnologiaDestino)){
                aux_array[i] = registros[j].nomeTecnologiaOrigem;
                aux_tam++;
            }
        }
        quickSort(aux_array, 0, aux_tam - 1);
        printf("\n");
    }

    free(aux_array);
    free(registros);

    for(int i = 0; i < n; i++){
        free(inputs_nomeTec[i]);
    }
    free(inputs_nomeTec);

}

void funcionalidade11(FILE* arq){
    printf("funcionalidade11!");
}
void funcionalidade12(FILE* arq){
    printf("funcionalidade12!");
}